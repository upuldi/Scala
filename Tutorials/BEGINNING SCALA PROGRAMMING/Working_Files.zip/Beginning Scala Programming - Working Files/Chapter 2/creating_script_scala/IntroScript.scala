println("Scala is amazingly concise")
