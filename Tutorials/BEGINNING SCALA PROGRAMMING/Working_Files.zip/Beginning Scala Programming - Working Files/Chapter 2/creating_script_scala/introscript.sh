#!/bin/sh
  exec scala "$0" "$@"
!#

println("Scala is amazingly concise")
