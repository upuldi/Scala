class Employee(firstName:String, lastName:String, department:Department)

class Department(name:String)

// println("Hello there") //Warning: this will not work
