object Options extends App {
   val middleName = Some("Antony")
   val middleName2:Some[String] = middleName
   val middleName2:Option[String] = middleName
}
