val a = 10
val result = if (a < 10) "Less than 10"
             else if (a > 10) "Greater than 10"
             else "It is 10!"
println(result)
