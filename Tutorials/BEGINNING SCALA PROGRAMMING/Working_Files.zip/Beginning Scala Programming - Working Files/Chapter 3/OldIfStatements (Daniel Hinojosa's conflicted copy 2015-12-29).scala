val a = 10
var result = ""

if (a < 10) result = "Less than 10"
else if (a > 10) result = "Greater than 10"
else result = "It is 10!"

println(result)
