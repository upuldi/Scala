lazy val a = 10 + b
lazy val b = 19
println(a)
