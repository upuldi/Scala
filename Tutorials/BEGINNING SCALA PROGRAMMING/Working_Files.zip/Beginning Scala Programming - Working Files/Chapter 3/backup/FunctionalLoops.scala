println((100 to 1 by -1).mkString(","))
