val a = 10
val result = if (a < 10) "Less than 10"
             else if (a > 10) "More than 10"
             else "Equal to 10" 
println(result)
