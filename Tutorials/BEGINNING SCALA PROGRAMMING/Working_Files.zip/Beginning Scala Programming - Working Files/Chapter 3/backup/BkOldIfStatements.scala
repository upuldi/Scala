val a = 10
var result = ""
if (a < 10) {
   result = "Less than 10"
} else if (a > 10) {
   result = "More than 10"
} else {
   result = "Equal to 10"
}
println(result)
