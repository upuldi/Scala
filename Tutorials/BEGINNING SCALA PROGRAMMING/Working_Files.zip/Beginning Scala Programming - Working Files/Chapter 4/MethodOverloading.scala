def addNum(x:Int) = x + 1
def addNum(y:Double) = y + 30.0
def addNum(z:String) = z + 19

println(addNum("Hello "))
println(addNum(30))
println(addNum(40.0))

def addTen(x:Int):Int = x + 10
def addTen(x:Double):Double = x + 19.0
println(addTen(40))
