def add(x:Int, y:Int) = x + y
def subtract(x:Double, y:Double) = x - y
println(add(subtract(10,3).round.toInt, subtract(100,32).round.toInt))

