def add(x:Int, y:Int) = {
   if (x > 10) (x+y).toString
   else x + y
}

println(add(4,10))
