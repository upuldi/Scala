def add(x:Int, y:Int) = x + y

println(add(6,7))

def numberStatus(a:Int) = 
  if (a < 10) "Less than 10"
  else if (a > 10) "Greater than 10"
  else "It is 10!"
