object RunnerApp extends App {
  println("Hello, Scala Edition")
}
