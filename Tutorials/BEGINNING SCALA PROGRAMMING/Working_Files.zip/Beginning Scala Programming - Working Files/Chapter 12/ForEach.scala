object ForEach extends App {
  val a = 1 to 10
  a foreach println
}
